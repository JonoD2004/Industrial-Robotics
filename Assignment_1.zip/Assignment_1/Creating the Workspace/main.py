"""
Lab Assignment 1 - Dual Cobot Assembly Task
Author: <Jonathan Davied>
Date: <2025-09-03>
"""

import numpy as np
import matplotlib.pyplot as plt
import time
import keyboard
from scipy import linalg
from spatialmath import SE3
from spatialmath.base import transl, trotx, troty, tr2rpy, r2q
from roboticstoolbox import jtraj
import roboticstoolbox as rtb
import swift
import spatialgeometry as geometry
import os
import asyncio
from ir_support import LinearUR3
from math import pi
import Calculations
import Movements
import Setup

# Each brick is 0.0667x * 0.1334y * 0.0334z
# but ive rotated it to be 0.1334x * 0.0667y * 0.0334z
   

if __name__ == "__main__":
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        asyncio.set_event_loop(asyncio.new_event_loop())

    # launch the environment
    environment = swift.Swift()
    environment.launch()
    #x_pos_limit, x_neg_limit, y_pos_limit, y_neg_limit = Calculations.Calculate_Robot_Reach()

    environment, robot = Setup.setup_robot(environment) # Setup the workspace and get robot,
    environment, robot = Setup.setup_gripper(environment, robot) # Setup the gripper
    environment, bricks, poses = Setup.setup_bricks(environment, robot) # Setup the bricks and get their poses
    # steps
    wall_poses = np.array([SE3(-0.15, 1, 0), SE3(0, 1, 0), SE3(0.15, 1, 0), 
                          SE3(-0.15, 1, 0.0334), SE3(-0.15, 1, 0.0334), SE3(0, 1, 0.0334), 
                          SE3(0.15, 1, 0.0668), SE3(-0.15, 1, 0.0668), SE3(-0.15, 1, 0.0668)])  # wall poses to build a wall
    for i, brick in enumerate(bricks):
        target = wall_poses[i]  # assign corresponding wall pose
        environment, brick = Movements.pick_and_place(robot, environment, brick, target)

    environment.hold()
    pass