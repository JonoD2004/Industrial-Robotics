import numpy as np
import matplotlib.pyplot as plt
import time
import keyboard
from scipy import linalg
from spatialmath import SE3
from spatialmath.base import transl, trotx, troty, tr2rpy, r2q
from roboticstoolbox import jtraj
import roboticstoolbox as rtb
import swift
import spatialgeometry as geometry
import os
import asyncio
from ir_support import LinearUR3
from math import pi
import Calculations

def pick_and_place(robot, environment, brick, target_pose, steps=50):
    # move linear rail to target x position of brick (if x position exceeds rail limits, move to closest limit)
    x_target = max(robot.q_min[0], min(robot.q_max[0], brick.pose.t[0]))
    robot.q[0] = x_target
    environment.step(0.1)
    
    # calculate the inverse kinematics for the target pose of the brick
    above_brick = SE3(brick.pose.t[0], brick.pose.t[1], brick.pose.t[2] + 0.1) @ SE3.Rx(pi)
    IK_brick = Calculations.Calculate_Inverse_Kinematics(robot, above_brick)
    environment.step(0.05)
    
    # move the arm to pose of the target changing the orientation so the gripper is facing down
    at_brick = SE3(brick.pose.t[0], brick.pose.t[1], brick.pose.t[2]) @ SE3.Rx(pi)
    IK_brick = Calculations.Calculate_Inverse_Kinematics(robot, at_brick, environment, steps=100)
    environment.step(0.05)
    
    # set the bricks pose to equal the target pose
    brick.pose = SE3(0,0,0)  # optional: attach to gripper
    environment.step(0.05)
    
    # move the arm back to base
    above_target = SE3(target_pose.t[0], target_pose.t[1], target_pose.t[2] + 0.1) @ SE3.Rx(pi)
    IK_target = Calculations.Calculate_Inverse_Kinematics(robot, above_target, environment, steps=100)
    environment.step(0.05)
    
    # Lower to wall pose
    q_place = robot.ikine_LM(target_pose).q
    IK_target = Calculations.Calculate_Inverse_Kinematics(robot, target_pose, environment, steps=100)
    environment.step(0.05)
        
    # calculate the inverse kinematics for the target pose
    brick.pose = target_pose
    environment.step(0.05)
    
    # move the arm to pose of the wall
    q_home = np.zeros(robot.n)
    IK_home = Calculations.Calculate_Inverse_Kinematics(robot, SE3(0,0,0), environment, steps=100)
    environment.step(0.05)
    print("Pick-and-place completed!")
    
    return environment
    
    
def execute_trajectory(robot, environment, q_start, q_goal, steps=100, dt=0.2):
    traj = rtb.jtraj(q_start, q_goal, steps).q
    for q in traj:
        robot.q = q
        environment.step(0.05)